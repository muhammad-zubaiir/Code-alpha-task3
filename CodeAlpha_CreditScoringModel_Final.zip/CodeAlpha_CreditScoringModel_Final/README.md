# CodeAlpha — Credit Scoring Model

## Objective
Predict an individual's creditworthiness using synthetic financial data.

## Approach
- Models: Logistic Regression, Decision Tree, Random Forest
- Metrics: Precision, Recall, F1-Score, ROC-AUC
- Visuals: ROC curves + Confusion matrix of best model

## How to Run
```bash
pip install -r requirements.txt
jupyter notebook CreditScoringModel.ipynb
```

## Outputs
- figures/roc_curves.png
- figures/confusion_matrix_best.png
- metrics_report.json
